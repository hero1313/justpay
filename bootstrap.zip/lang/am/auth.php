<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Այս հավատարմագրերը չեն համապատասխանում մեր գրառումներին։',
    'password' => 'Տրամադրված գաղտնաբառը սխալ է։',
    'throttle' => 'Չափից շատ մուտք գործելու փորձեր: Խնդրում եմ նորից փորձեք :seconds վայրկյանից։',

];
