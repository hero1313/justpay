@extends('index')
@section('content')
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


    <button type="button" class="btn btn-dark mb-4" data-toggle="modal" data-target="#addProductModal">
        @lang('public.add_product')
    </button>

    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">@lang('public.id')</th>
                <th scope="col">@lang('public.image')</th>
                <th scope="col">@lang('public.name')</th>
                <th scope="col">@lang('public.code')</th>
                <th scope="col">@lang('public.price')</th>
                <th scope="col">@lang('public.description')</th>
                <th scope="col">@lang('public.action')</th>
            </tr>
        </thead>
        <tbody>
            @if (!empty($products) && $products->count())
                @foreach ($products as $product)
                    <tr class="products-tr">
                        <th scope="row">{{ $product->id }}</th>
                        <td><img src="assets/image/{{ $product->image }}" alt=""></td>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->code }}</td>
                        <td>{{ $product->price }}</td>
                        <td>{{ $product->description }}</td>
                        <td>
                            <form id="delete-form" action="remove-save-product/{{ $product->id }}" method="POST">
                                @csrf
                                @method('PUT')
                                <button class="btn btn-danger" type="submit">@lang('public.delete')</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="10">
                        <div>{!! $products->appends(Request::all())->links() !!}</div>
                    </td>
                </tr>
            @else
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            @endif

        </tbody>
    </table>

    <div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductModal"
        aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="add-product" method="POST" enctype='multipart/form-data'>
                    @csrf
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="add">
                            <h5 class="product-name order-product">@lang('public.add_new')</h5>
                            <h6 class="pre-text">@lang('public.provide')</h6>
                            <hr>
                            <div class="row order-info">
                                <div class="col-12 col-lg-6">
                                    <div>
                                        <h5 class="product-name order-product">@lang('public.product')</h5>
                                        <input type="text" name='name' class="form-control order-input prod-name">
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product">@lang('public.description')</h5>
                                        <textarea class="form-control order-input textarea-order" id='prod_desc' name='description'></textarea>
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product">@lang('public.code')</h5>
                                        <input type="text" name='code' class="form-control order-input prod-name">
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product">@lang('public.price')</h5>
                                        <div class="flex price-4">
                                            <input type="number" class="form-control order-input input-price"
                                                id='prod_price' name='price' step="0.01">
                                            <select class="form-select select-order select-price" aria-placeholder="price"
                                                aria-label="Default select example" id='prod_valuta' name='currency'>
                                                @if (Auth::user()->gel == 1)
                                                    <option value="1">gel</option>
                                                @endif
                                                @if (Auth::user()->euro == 1)
                                                    <option value="2">euro</option>
                                                @endif
                                                @if (Auth::user()->usd == 1)
                                                    <option value="3">usd</option>
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="upload-img">
                                        <h5 class="product-name order-product">@lang('public.image')</h5>
                                        <input type="file" class="image-input" name="image">
                                    </div>
                                    <img src='' id='review_image'>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">@lang('public.close')</button>
                        <button type="submit" class="btn btn-primary">@lang('public.add_product')</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @if ($errors->any())
        <script>
            swal("{{ $errors->first() }}", "", "error");
        </script>
    @endif

@stop
