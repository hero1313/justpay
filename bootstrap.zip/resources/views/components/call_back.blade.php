<h1 class="thank">@lang('public.thank')</h1>
<style>
    .thank{
    text-align: center;
    margin: auto;
    height: max-content;
    margin-top: 43vh;
    font-size: 50px;
    font-family: monospace;
}
</style>
