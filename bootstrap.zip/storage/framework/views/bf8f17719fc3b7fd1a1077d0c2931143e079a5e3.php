<?php $__env->startSection('content'); ?>
<div class="col-12main-transaction" style="overflow-x: auto;">
    <div class="table-responsive text-nowrap ">
      <table class="table table-transaction ">
        <thead>
          <tr class="order-tr">
            <th scope="col">pay id</th>
            <th scope="col">total</th>
            <th scope="col">valuta</th>
            <th scope="col">pay method</th>
            <th scope="col">created</th>
            <th scope="col">status</th>
            <th scope="col">action</th>
          </tr>
        </thead>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="body-table">
                    <td><?php echo e($transaction->pay_id); ?></td>
                    <td><?php echo e($transaction->total); ?></td>
                    <td>
                        <?php if($transaction->valuta == 1): ?>
                            GEL
                        <?php elseif($transaction->valuta == 2): ?>
                            EURO
                        <?php elseif($transaction->valuta == 3): ?>
                            USD
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($transaction->pay_method == 1): ?>
                            TBC PAY
                        <?php elseif($transaction->pay_method == 2): ?>
                            IPAY
                        <?php elseif($transaction->pay_method == 3): ?>
                            STRIPE
                        <?php elseif($transaction->pay_method == 4): ?>
                            PAYZE
                        <?php endif; ?>

                    </td>
                    <td><?php echo e($transaction->created_at); ?></td>
                    <td><?php echo e($transaction->status); ?></td>
                    <td>
                        <form action="<?php echo e(route('transaction.cancel',['pay_id' => $transaction->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary" type="submit">REFUND</button>
                        </form>
                    </td>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay - Copy\resources\views/components/transactions.blade.php ENDPATH**/ ?>