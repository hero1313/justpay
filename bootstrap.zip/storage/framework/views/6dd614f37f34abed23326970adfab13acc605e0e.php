<div class="modal fade " id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="add">
                    <h5 class="product-name order-product"><?php echo app('translator')->get('public.add_new'); ?></h5>
                    <h6 class="pre-text"><?php echo app('translator')->get('public.provide'); ?></h6>
                    <hr>
                    <div class="row order-info">
                        <div class="col-12 col-lg-6">
                            <br>
                            <div class="dropdown">
                                <button class="btn new-product-btn dropdown-toggle" onclick="myFunction()" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    აირჩიეთ პროდუქტი
                                </button>
                                <div id="myDropdown" class="dropdown-content">
                                    <input type="text" placeholder="Search.." id="myInput" onkeyup="filterFunction()">

                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="option save-li" id="product_<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?>

                                    </li>
                                    <script>
                                        $("#product_<?php echo e($product->id); ?>").click(function() {
                                            var id = $("#product_<?php echo e($product->id); ?>").val();
                                            $.ajax({
                                                type: 'get',
                                                url: '<?php echo e(url("/addProductsAjax")); ?>',
                                                data: 'id=' + id,
                                                success: function(response) {
                                                    console.log(response)
                                                    $('#prod_name').val(response[0].name);
                                                    $('#prod_desc').val(response[0].description);
                                                    $('#prod_price').val(response[0].price);
                                                    $('#saved_image').val(response[0].image);
                                                    $("#review_image").last().attr("src", '../assets/image/' + response[0].image);
                                                    $("#review_image").addClass("review-image");
                                                    $("#myDropdown").removeClass("show");
                                                }
                                            })
                                        })
                                    </script>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                            <br>
                            <div>
                                <h5 class="product-name order-product"><?php echo app('translator')->get('public.product'); ?></h5>
                                <input type="text" id='prod_name' name='prod_name' class="form-control order-input prod-name">
                            </div>
                            <div>
                                <h5 class="product-name order-product"><?php echo app('translator')->get('public.description'); ?></h5>
                                <textarea class="form-control order-input textarea-order" id='prod_desc' name='prod_desc'></textarea>
                            </div>
                            <div>
                                <h5 class="product-name order-product"><?php echo app('translator')->get('public.quantity'); ?></h5>
                                <div class="flex price-4">
                                    <input type="number" class="form-control order-input input-price" id='prod_amount' value="1" name='prod_amount'>
                                </div>
                            </div>
                            
                            <input type="number" class="form-control order-input input-price" id='prod_price' placeholder="ფასი" name='prod_price'>

                            <input type="number" class="form-control order-input input-price" id='prod_discount_price' placeholder="ფასდაკლებული ფასი" name='discount_price'>
                            <select class="form-select select-order select-price" aria-placeholder="price" aria-label="Default select example" id='prod_valuta' name='prod_valuta'>
                                <?php if(Auth::user()->gel == 1): ?>
                                <option value="1">gel</option>
                                <?php endif; ?>
                                <?php if(Auth::user()->euro == 1): ?>
                                <option value="2">euro</option>
                                <?php endif; ?>
                                <?php if(Auth::user()->usd == 1): ?>
                                <option value="3">usd</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="">
                                <h5 class="product-name order-product"><?php echo app('translator')->get('public.save_future'); ?></h5>
                                <select class="form-select select-order" aria-label="Default select example" id='prod_save' name='prod_save'>
                                    <option value="0" selected><?php echo app('translator')->get('public.no'); ?></option>
                                    <option value='1'><?php echo app('translator')->get('public.yes'); ?></option>
                                </select>
                            </div>
                            <div class="upload-img">
                                <h5 class="product-name order-product"><?php echo app('translator')->get('public.image'); ?></h5>
                                <input type="file" id="image" class="image-input" name="image[]">
                            </div>
                            <div>
                                <input type="hidden" name="saved_image" value="product.png" id="saved_image">
                            </div>
                            <img src='' id='review_image'>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('public.close'); ?></button>
                <button type="submit" id="reset" class="btn btn-primary"><?php echo app('translator')->get('public.add_product'); ?></button>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/justpay/public/resources/views/components/add_product_modal.blade.php ENDPATH**/ ?>