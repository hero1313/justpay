<?php $__env->startSection('content'); ?>
<div class="col-12main-transaction" style="overflow-x: auto;">
    <div class="table-responsive text-nowrap ">
      <table class="table table-transaction ">
        <thead>
          <tr class="order-tr">
            <th scope="col"><?php echo app('translator')->get('public.pay_id'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.total'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.currency'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.pay_method'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.create_date'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.status'); ?></th>
            <th scope="col"><?php echo app('translator')->get('public.action'); ?></th>
          </tr>
        </thead>
            <?php if(!empty($transactions) && $transactions->count()): ?>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="body-table">
                    <td> <a href="transaction/<?php echo e($transaction->id); ?>"><?php echo e($transaction->pay_id); ?></a> </td>
                    <td><?php echo e($transaction->total); ?></td>
                    <td>
                        <?php if($transaction->valuta == 1): ?>
                            GEL
                        <?php elseif($transaction->valuta == 2): ?>
                            EURO
                        <?php elseif($transaction->valuta == 3): ?>
                            USDs
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($transaction->pay_method == 1): ?>
                            TBC PAY
                        <?php elseif($transaction->pay_method == 2): ?>
                            IPAY
                        <?php elseif($transaction->pay_method == 3): ?>
                            STRIPE
                        <?php elseif($transaction->pay_method == 4): ?>
                            PAYZE
                        <?php endif; ?>

                    </td>
                    <td><?php echo e($transaction->created_at); ?></td>
                    <td><?php if($transaction->transaction_status == 1): ?>
                        <button class="btn btn-success">გადახდილი</button>
                        <?php elseif($transaction->transaction_status == 0): ?>
                            <button class="btn btn-primary">აქტიური</button>
                        <?php elseif($transaction->transaction_status == -1): ?>
                            <button class="btn btn-danger">დაბრუნებული</button>
                        <?php endif; ?></td>
                    <td>
                        <?php if($transaction->transaction_status != -1): ?>
                        <form action="<?php echo e(route('transaction.cancel',['pay_id' => $transaction->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary" type="submit">REFUND</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="10"> <div><?php echo $transactions->appends(Request::all())->links(); ?></div>
                </td>
            </tr>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>
      </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/transactions.blade.php ENDPATH**/ ?>