<?php $__env->startSection('content'); ?>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col"><?php echo app('translator')->get('public.id'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.image'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.name'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.price'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.description'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php if(!empty($products) && $products->count()): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="products-tr">
                <th scope="row"><?php echo e($product->id); ?></th>
                <td><img src="assets/image/<?php echo e($product->image); ?>" alt=""></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->price); ?></td>
                <td><?php echo e($product->description); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="10"> <div><?php echo $products->appends(Request::all())->links(); ?></div>
                </td>
              </tr>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>

    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/products.blade.php ENDPATH**/ ?>