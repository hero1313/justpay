<h1 class="thank"><?php echo app('translator')->get('public.try_again'); ?></h1>

<style>
    .thank{
    text-align: center;
    margin: auto;
    height: max-content;
    margin-top: 42vh;
    font-size: 50px;
    font-family: monospace;
}
</style>
<?php /**PATH /home/justpay/site/public/resources/views/components/redirect.blade.php ENDPATH**/ ?>