<?php $__env->startSection('content'); ?>
  <div class="col-12 main-order">
        <form  action='<?php echo e(route('update.setting')); ?>' enctype='multipart/form-data' method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col col-12 main-bank">
                <div class="row pass1" style="margin: 20px 10.3%;">
                    <div class="col-12 center pass-change-name"><?php echo app('translator')->get('public.parameters'); ?></div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.name'); ?></label>
                        <input class="form-control" type="text" id='uname' name='name' value='<?php echo e(Auth::user()->name); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.email'); ?></label>
                        <input class="form-control" type="text" id='email' name='email' value='<?php echo e(Auth::user()->email); ?>'>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.telephone'); ?></label>
                        <input class="form-control" type="text" id='tel' name='number' value='<?php echo e(Auth::user()->number); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.identification_number'); ?></label>
                        <input class="form-control" type="text" id='saident' name='identity_number' value='<?php echo e(Auth::user()->identity_number); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.address'); ?></label>
                        <input class="form-control" type="text" id='addr' name='address' value='<?php echo e(Auth::user()->address); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.bank_code'); ?></label>
                        <input class="form-control" type="text" id='bank_code' name='bank_code' value='<?php echo e(Auth::user()->bank_code); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.account_number'); ?></label>
                        <input class="form-control" type="text" id='bank_angarish' name='account_number' value='<?php echo e(Auth::user()->account_number); ?>'>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <label for="inputText"><?php echo app('translator')->get('public.company_logo'); ?></label> <br>
                        <input type="file" id='mlogo' name='logo'>
                        <img class="company-logo" src="../assets/image/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="">
                        </div>
                    </div>
                    <div class="container-fluid">
                        <h3 class="font-weight-bold mt-3 "><?php echo app('translator')->get('public.currency'); ?></h3>
                        <div class="flex ">
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input " type="checkbox" value="1" name="gel"  <?php echo (Auth::user()->gel == 1 ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                GEL
                                </label>
                            </div>
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input " type="checkbox" value="1" name="euro" <?php echo (Auth::user()->euro == 1 ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                EURO
                                </label>
                            </div>
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input " type="checkbox" value="1" name="usd" <?php echo (Auth::user()->usd == 1 ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                USD
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <h3 class="font-weight-bold mt-3 "><?php echo app('translator')->get('public.payment'); ?></h3>
                        <div class="flex ">
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input tbc form-check-input" type="checkbox" value="1" name="tbc"  <?php echo (Auth::user()->tbc_id != null && Auth::user()->tbc_key != null ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                TBC
                                </label>
                            </div>
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input payzes form-check-input" type="checkbox" value="1" name="payze" <?php echo (Auth::user()->payze_id != null && Auth::user()->payze_key != null ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                payze
                                </label>
                            </div>
                        </div>
                        <div class="flex ">
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input stripe form-check-input" type="checkbox" value="1" name="stripe" <?php echo (Auth::user()->stripe_id != null && Auth::user()->stripe_key != null ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                Stripe
                                </label>
                            </div>
                            <div class="form-check pay-check form-switch">
                                <input class="form-check-input ipay form-check-input" type="checkbox" value="1" name="ipay" <?php echo (Auth::user()->ipay_id != null && Auth::user()->ipay_key != null ? ' checked' : ''); ?>>
                                <label class="form-check-label" for="flexCheckDefault">
                                Ipay
                                </label>
                            </div>
                        </div>
                        <div class="row">
                        <div class='mb-4 full hide' id='tpay_div'>
                            <div class="note note-primary ">
                            <h6 class="font-weight-bold">TBC Checkout</h6>
                            <hr>
                            <div class='row'>
                                <div class='col-12 col-md-6'>
                                <div class='form-group'>
                                    <label for='tpay_userid'>Tpay Client ID</label>
                                    <input class='form-control' type='text' name='tbc_id' value="<?php echo e(Auth::user()->tbc_id); ?>" id='tpay_client_id'>
                                </div>
                                </div>
                                <div class='col-md-6 col-12 '>
                                <div class='form-group'>
                                    <label for='tpay_secret'>TPay Secret</label>
                                    <input class='form-control' type='text' name='tbc_key' value="<?php echo e(Auth::user()->tbc_key); ?>" id='tpay_secret'>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class='mb-4 full hide' id='payz_div'>
                            <div class="note note-light">
                            <h6 class="font-weight-bold">Payze Checkout</h6>
                            <hr>
                            <div class='row'>
                                <div class='col-12 col-md-6'>
                                <div class='form-group'>
                                    <label for='payz_api_key'>Payze Api-Key</label>
                                    <input class='form-control' type='text' name='payze_id' id='payz_api_key' value="<?php echo e(Auth::user()->payze_id); ?>">
                                </div>
                                </div>
                                <div class='col-md-6 col-12 '>
                                <div class='form-group'>
                                    <label for='bank_acc'>Payze api-secret</label>
                                    <input class='form-control' type='text' name='payze_key' id='payz_api_secret' value="<?php echo e(Auth::user()->payze_key); ?>"></td>
                                </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            </div>
                        </div>
                        <div class='mb-4 full hide' id='stripe_div' >
                            <div class="note note-primary">
                            <h6 class="font-weight-bold">Stripe Details</h6>
                            <hr>
                            <div class='row'>
                                <div class='col-12 col-md-6'>
                                <div class='form-group'>
                                    <label for='bank_acc'>Stripe Public Key</label>
                                    <input class='form-control' type='text' name='stripe_id' id='stripe_public_key' value="<?php echo e(Auth::user()->stripe_id); ?>">
                                </div>
                                </div>
                                <div class='col-md-6 col-12 '>
                                <div class='form-group'>
                                    <label for='bank_acc'>Stripe Secret Key</label>
                                    <input class='form-control' type='text' name='stripe_key' id='stripe_secret_key' value="<?php echo e(Auth::user()->stripe_key); ?>">
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        <div class='mb-4 full hide' id='ipay_div' >
                            <div class="note note-primary">
                            <h6 class="font-weight-bold">Ipay Details</h6>
                            <hr>
                            <div class='row'>
                                <div class='col-12 col-md-6'>
                                <div class='form-group'>
                                    <label for='ipay_client_id'>Ipay Client ID</label>
                                    <input class='form-control' type='text' name='ipay_id' id='ipay_client_id' value="<?php echo e(Auth::user()->ipay_id); ?>">
                                </div>
                                </div>
                                <div class='col-md-6 col-12 '>
                                <div class='form-group'>
                                    <label for='ipay_secret_key'>Ipay Secret Key</label>
                                    <input class='form-control' type='text' name='ipay_key' id='ipay_secret_key' value="<?php echo e(Auth::user()->ipay_key); ?>">
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="col-12  col-md-6 input-name2 ">
                        <div class="textOnInput ">
                        <input class="form-control" type="submit" value='<?php echo app('translator')->get('public.save'); ?>' style='background-color:green; color:white;'>
                        </div>
                    </div>
                </div>
        </div>
        </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/setting.blade.php ENDPATH**/ ?>