<?php echo e($slot); ?>

<?php /**PATH /home/justpay/public/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>