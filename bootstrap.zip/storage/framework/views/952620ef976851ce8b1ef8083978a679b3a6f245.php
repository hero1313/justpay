<h1 class="thank">Thank You</h1>
<style>
    .thank{
    text-align: center;
    margin: auto;
    height: max-content;
    margin-top: 43vh;
    font-size: 50px;
}
</style>
<?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/call_back.blade.php ENDPATH**/ ?>