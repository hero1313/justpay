<?php $__env->startSection('content'); ?>
    <div class="col-12main-transaction" style="overflow-x: auto;">
        <div class="table-responsive text-nowrap ">
            <table class="table table-transaction ">
                <thead>
                    <tr class="order-tr">
                        <th scope="col"><?php echo app('translator')->get('public.name'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.number'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.total'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.currency'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.pay_method'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.pay_id'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.create_date'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.status'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('public.action'); ?></th>
                    </tr>
                </thead>
                <?php if(!empty($transactions) && $transactions->count()): ?>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody class="body-table">
                            <td><?php echo e($transaction->full_name); ?></td>
                            <td><?php echo e($transaction->number); ?></td>
                            <td><?php echo e($transaction->total); ?></td>
                            <td>
                                <?php if($transaction->valuta == 1): ?>
                                    GEL
                                <?php elseif($transaction->valuta == 2): ?>
                                    EURO
                                <?php elseif($transaction->valuta == 3): ?>
                                    USDs
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($transaction->pay_method == 1): ?>
                                    TBC PAY
                                <?php elseif($transaction->pay_method == 2): ?>
                                    IPAY
                                <?php elseif($transaction->pay_method == 4): ?>
                                    STRIPE
                                <?php elseif($transaction->pay_method == 3): ?>
                                    PAYZE
                                <?php endif; ?>

                            </td>
                            <td> <a href="transaction/<?php echo e($transaction->id); ?>"><?php echo e($transaction->pay_id); ?></a> </td>
                            <td><?php echo e($transaction->created_at); ?></td>
                            
                            <td>
                                <?php if($transaction->transaction_status == 1): ?>
                                    <button class="btn btn-success"> <?php echo app('translator')->get('public.paid'); ?></button>
                                <?php elseif($transaction->transaction_status == 2): ?>
                                    <!-- <a href="repeatcallback/<?php echo e($transaction->id); ?>">
                                        <button class="btn btn-primary">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16">
                                                <path fill-rule="evenodd"
                                                    d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z" />
                                                <path
                                                    d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z" />
                                            </svg>
                                        </button>
                                    </a> -->
                                    <button class="btn btn-danger"><?php echo app('translator')->get('public.discontinued'); ?></button>
                                <?php elseif($transaction->transaction_status == -1): ?>
                                    <button class="btn btn-info"> <?php echo app('translator')->get('public.returned'); ?></button>
                                <?php elseif($transaction->transaction_status == 0): ?>
                                    <button class="btn btn-danger"><?php echo app('translator')->get('public.discontinued'); ?></button>
                                <?php elseif($transaction->transaction_status == -2): ?>
                                    <button class="btn btn-danger"> <?php echo app('translator')->get('public.Rejected'); ?></button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($transaction->transaction_status == 1): ?>
                                    <form action="<?php echo e(route('transaction.cancel', ['pay_id' => $transaction->id])); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-primary" type="submit"> <?php echo app('translator')->get('public.refund'); ?></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="10">
                            <div><?php echo $transactions->appends(Request::all())->links(); ?></div>
                        </td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="10">There are no data.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/components/transactions.blade.php ENDPATH**/ ?>