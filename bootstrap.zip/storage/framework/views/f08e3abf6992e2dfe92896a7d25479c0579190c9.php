
<?php $__env->startSection('content'); ?>
    <div class="container py-3">

        <div class="d-flex justify-content-between align-items-center">
            <h3 class="text-center">Texts for main site</h3>
            <div>
                <a class="btn btn-primary btn-md" href="<?php echo e(route('texts.create')); ?>">Create New</a>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-sm table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>Variable</th>
                        <?php $__currentLoopData = config('custom_vars.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($lang); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->var); ?></td>
                            <?php $__currentLoopData = config('custom_vars.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item->$lang); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>

    <script>
        $(document).ready(function() {

            $(document).on("change", ".form-check-input", function() {
                var checked = $(this).is(':checked');
                var tr = $(this).closest("tr");
                var tds = $(tr).find("td");
                var readonly = (checked ? false : true);
                $(tds).each(function(i, e) {
                    if (i == 0 || i == 1) {
                        return true;
                    } else {
                        $(e).find("input:text").prop('disabled', readonly);
                    }
                });

                if ($(".form-check-input:checked").length > 0) {
                    $(".submit-btn").show();
                } else {
                    $(".submit-btn").hide();
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/site/public/resources/views/admin/texts/index.blade.php ENDPATH**/ ?>