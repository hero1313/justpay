<h1 class="thank">Please try again</h1>

<style>
    .thank{
    text-align: center;
    margin: auto;
    height: max-content;
    margin-top: 42vh;
    font-size: 50px;
    font-family: monospace;
}
</style>
<?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/redirect.blade.php ENDPATH**/ ?>