<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<head>
    <title><?php echo app('translator')->get('public.invoice'); ?> <?php echo e($company->name); ?></title>
    <meta property="og:title" content="<?php echo app('translator')->get('public.invoice'); ?> - <?php echo e($company->name); ?>" />

</head>

<head>
    <style type="text/css">
        #map {
            width: 100%;
            height: 300px;
        }
    </style>
</head>
<div class="preview-order container">
    <div class="row">
        <div class="col-12 col-md-6">
            <section class="brand-section d-flex">
                <img src="../assets/image/<?php echo e($company->profile_photo_path); ?>" alt="">
                <h4><?php echo e($company->name); ?></h4>
            </section>
            <section class="preview-products">
                <table class="table preview-table">
                    <thead>
                        <tr class="preview-thead-tr">
                            <th><?php echo app('translator')->get('public.product'); ?></th>
                            <th><?php echo app('translator')->get('public.quantity'); ?></th>
                            <th><?php echo app('translator')->get('public.price'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="preview-tr">
                                <td>
                                    <div class="prod-img d-flex">
                                        <img src="../assets/image/<?php echo e($product->image); ?>" alt="">
                                        <h6><?php echo e($product->name); ?></h6>
                                    </div>
                                </td>
                                <td>
                                    <h6 class="preview-quantity"><?php echo e($product->amount); ?></h6>
                                </td>
                                <td>
                                    <h6 class="preview-price"><?php echo e($product->price); ?>

                                        <?php if($product->currency == 1): ?>
                                            GEL
                                        <?php elseif($product->currency == 2): ?>
                                            EURO
                                        <?php elseif($product->currency == 3): ?>
                                            USD
                                        <?php endif; ?>
                                    </h6>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section>
            <section class="preview-total">
                <div class="d-flex">
                    <h5 class="preview-subtotal"><?php echo app('translator')->get('public.subtotal'); ?></h5>
                    <h5><?php echo e($subtotal); ?> <?php echo e($currency); ?></h5>
                </div>
                <div class="d-flex">
                    <h5 class="preview-subtotal"><?php echo app('translator')->get('public.shiping_price'); ?></h5>
                    <h5>
                        <?php if($order->shiping != 0): ?>
                            <?php echo e($order->shiping); ?> <?php echo e($currency); ?>

                        <?php else: ?>
                            <?php echo app('translator')->get('public.free'); ?>
                        <?php endif; ?>
                    </h5>
                </div>
                <hr>
                <div class="d-flex">
                    <h4 class="preview-total-h4"><?php echo app('translator')->get('public.total'); ?></h4>
                    <h4><?php echo e($order->total); ?> <?php echo e($currency); ?></h4>
                </div>
            </section>
        </div>
        <div class="col-12 col-md-6">
            <form id="sub">
                <h5 class="contact-info"><?php echo app('translator')->get('public.contact_info'); ?></h5>
                <div class="opt-div opt-div-order row ">
                    <?php if($order->full_name == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.full_name'); ?>" name='name'
                                class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->number == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.number'); ?>" name='number'
                                class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->address == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.address'); ?>" name='address'
                                class="  form-control">
                        </div>
                    <?php endif; ?>

                    <?php if($order->address == 1): ?>
                        <div class="col-6" style=" padding: 15px 10px;">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalmap">
                                რუკაზე მონიშვნა
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="modalmap" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">მდებარეობა მონიშნეთ რუკაზე
                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="container mt-3 pb-3">
                                            <input id="pac-input" class="controls loc-input" type="text"
                                                placeholder="Search Box" />
                                            <div id="map"></div>
                                        </div>
                                        <script>
                                            function initAutocomplete() {
                                                const map = new google.maps.Map(document.getElementById("map"), {
                                                    center: {
                                                        lat: -33.8688,
                                                        lng: 151.2195
                                                    },
                                                    zoom: 13,
                                                    mapTypeId: "roadmap",
                                                });
                                                // Create the search box and link it to the UI element.
                                                const input = document.getElementById("pac-input");
                                                const searchBox = new google.maps.places.SearchBox(input);

                                                map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
                                                // Bias the SearchBox results towards current map's viewport.
                                                map.addListener("bounds_changed", () => {
                                                    searchBox.setBounds(map.getBounds());
                                                });

                                                let markers = [];

                                                // Listen for the event fired when the user selects a prediction and retrieve
                                                // more details for that place.
                                                searchBox.addListener("places_changed", () => {
                                                    const places = searchBox.getPlaces();

                                                    if (places.length == 0) {
                                                        return;
                                                    }

                                                    // Clear out the old markers.
                                                    markers.forEach((marker) => {
                                                        marker.setMap(null);
                                                    });
                                                    markers = [];

                                                    // For each place, get the icon, name and location.
                                                    const bounds = new google.maps.LatLngBounds();

                                                    places.forEach((place) => {
                                                        if (!place.geometry || !place.geometry.location) {
                                                            console.log("Returned place contains no geometry");
                                                            return;
                                                        }

                                                        const icon = {
                                                            url: place.icon,
                                                            size: new google.maps.Size(71, 71),
                                                            origin: new google.maps.Point(0, 0),
                                                            anchor: new google.maps.Point(17, 34),
                                                            scaledSize: new google.maps.Size(25, 25),
                                                        };

                                                        // Create a marker for each place.
                                                        markers.push(
                                                            new google.maps.Marker({
                                                                map,
                                                                icon,
                                                                title: place.name,
                                                                position: place.geometry.location,
                                                            })
                                                        );
                                                        if (place.geometry.viewport) {
                                                            // Only geocodes have viewport.
                                                            bounds.union(place.geometry.viewport);
                                                        } else {
                                                            bounds.extend(place.geometry.location);
                                                        }

                                                    });
                                                    map.fitBounds(bounds);
                                                    map.addListener("click", (mapsMouseEvent) => {
                                                        // Close the current InfoWindow.
                                                        infoWindow.close();
                                                        // Create a new InfoWindow.
                                                        infoWindow = new google.maps.InfoWindow({
                                                            position: mapsMouseEvent.latLng,
                                                        });
                                                        infoWindow.setContent(
                                                            JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2)
                                                        );
                                                        infoWindow.open(map);
                                                    });
                                                });
                                            }
                                            window.initAutocomplete = initAutocomplete;
											initMap()
                                        </script>
                                        <script
                                            src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_MAP_KEY')); ?>&callback=initAutocomplete&libraries=places&v=weekly"
                                            defer></script>
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($order->email == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" name="email" placeholder="<?php echo app('translator')->get('public.email'); ?>" class=" form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->id_number == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.id_number'); ?>" name="id_number"
                                class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->special_code == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.special_code'); ?>" name="special_code"
                                class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->description == 1): ?>
                        <div class="col-12 ">
                            <textarea class="form-control textarea-order" rows="3" placeholder="<?php echo app('translator')->get('public.customers_info'); ?>"></textarea>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="d-block mt-4">
                    <h5 class="contact-info mb-4"><?php echo app('translator')->get('public.pay'); ?></h5>
                    <div class="bank-form flex">
                        <?php if($order->tbc == 1): ?>
                            <div class="form-check">
                                <input class="form-check-input mt-4" type="radio" id="tbc_checkbox">
                                <label class="form-check-label" for="flexCheckDefault">
                                    <div id="tbc_prev" class="bank-item-order">
                                        <img src="../assets/img/tbc.png" alt="">
                                    </div>
                                </label>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                    <div>
                        <button type="submit" class="btn btn-pay"><?php echo app('translator')->get('public.pay'); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .pac-container {
        z-index: 1111111;
    }

    .loc-input {
        padding: 11px !important;
        background: #fff !important;
    }
</style>
<?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    //     $( "#tbc_prev" ).click(function() {
    //        $('#sub').attr('action',"<?php echo e(route('tbcpayment', ['frontId' => $order->front_code])); ?>");
    //        $('#sub').submit();
    //    });

    $("#tbc_checkbox").change(function() {
        $('#sub').attr('action', "<?php echo e(route('tbcpayment', ['frontId' => $order->front_code])); ?>");
    });
</script>
<?php /**PATH /home/justpay/site/public/resources/views/components/googlemap.blade.php ENDPATH**/ ?>