<?php $__env->startSection('content'); ?>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col"><?php echo app('translator')->get('public.create_date'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.price'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.invoice_link'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.status'); ?></th>
        <th scope="col"><?php echo app('translator')->get('public.additional_information'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php if(!empty($orders) && $orders->count()): ?>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="products-tr">
            <th scope="row"><?php echo e($order->created_at); ?></th>
            <td><?php echo e($order->total); ?></td>
            <td><a href="/order/<?php echo e($order->front_code); ?>"><?php echo e($url); ?>/order/<?php echo e($order->front_code); ?></a></td>
            <td>
                <?php if($order->status == -1): ?>
                    <button type="button" class="btn btn-danger"><?php echo app('translator')->get('public.canceled'); ?></button>
                <?php elseif($order->status == 0): ?>
                    <button type="button" class="btn btn-primary"><?php echo app('translator')->get('public.active'); ?></button>
                <?php elseif($order->status == 1): ?>
                    <button type="button" class="btn btn-success"><?php echo app('translator')->get('public.payed'); ?></button>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->description); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td colspan="10"> <div><?php echo $orders->appends(Request::all())->links(); ?></div>
        </td>
      </tr>
    <?php else: ?>
        <tr>
            <td colspan="10">There are no data.</td>
        </tr>
    <?php endif; ?>

    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/orders.blade.php ENDPATH**/ ?>