<!DOCTYPE html>
<html>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <header>
        <img class="burger" src="../assets/img/burger.svg" alt="">
    </header>
    <div class="row">
        <?php echo $__env->make('layouts.hidden-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col col-sm-3  col-md-2  menu" >
             <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 col-lg-10  contents" >
            <?php echo $__env->yieldContent('content'); ?>
       </div>
    </div>
    <?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>


<?php /**PATH C:\Users\Admin\Desktop\justpay - Copy\resources\views/index.blade.php ENDPATH**/ ?>