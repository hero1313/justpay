<?php $__env->startSection('content'); ?>
    <form class="product-form"  action='<?php echo e(route('store.order')); ?>' enctype='multipart/form-data' method="POST">
    <?php echo csrf_field(); ?>
        <div class="col-12 main-product">
            <div class="row main-row">
                <div class="col-12   col-lg-5 pages">
                        <h5 class="product-name">Product</h5>
                        <div class="col-9  input-name2 ">
                        <button type="button" class="btn new-product-btn" data-toggle="modal" data-target="#exampleModalCenter">
                            add product
                        </button>
                        </div>
                        <br>
                        <div class="invoice_type">
                            <h5 class="product-name" data-toggle="collapse" data-target="#invoice_type_collapse" aria-expanded="false" aria-controls="collapseExample">Invoice Type <img src="../assets/img/down.svg" alt=""></h5>
                            <div class="collapse collapse-none" id="invoice_type_collapse">
                                <div class="radio-container col-11">
                                    <input type="radio" id="inv_type1" name="inv_type" value="1" checked onchange='preview_products();'>
                                    <label class="label-checkbox" for="inv_type1">One time invoice </label><button class="btn btn-one" data-toggle="tooltip" data-placement="top" title="აქ რასაც გვინდა ჭავწერთ">?</button>
                                    <br>
                                    <input type="radio" id="inv_typ2" name="inv_type" value="2"  onchange='preview_products();'>
                                    <label for="inv_type2">Multi order invoice</label><button class="btn btn-one" data-toggle="tooltip" data-placement="top" title="აქ რასაც გვინდა ჭავწერთ">?</button>
                                </div>
                            </div>
                        </div>
                        <div class="payment">
                        <h5 class="product-name " data-toggle="collapse" data-target="#requirements_collapse" aria-expanded="false" aria-controls="collapseExample" >Payment Requirements <img src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="requirements_collapse" >
                            <div>
                                <input type="checkbox" class="hs-1" name="fullname" value="1" id='req_fname_ch'>
                                <label class="label-checkbox " for="coding">Full Name</label>
                            </div>
                            <div>
                                <input type="checkbox"class="hs-2" name="telephone" value="1" id='req_tel_ch'>
                                <label class="label-checkbox " for="coding">Telephone</label>
                            </div>
                            <div>
                                <input type="checkbox" class="hs-3" name="address" value="1" id='req_addr_ch'>
                                <label class="label-checkbox " for="coding">Address</label>
                            </div>
                            <div>
                                <input type="checkbox" class="hs-4" name="email" value="1" id='req_email_ch'>
                                <label class="label-checkbox " for="coding">Email</label>
                            </div>
                            <div>
                                <input type="checkbox" class="hs-5" name="id_number" value="1" id='req_id_ch'>
                                <label class="label-checkbox " for="coding">ID number</label>
                            </div>
                            <div>
                                <input type="checkbox" class="hs-6" name="spec_code" value="1" id='req_code_ch' >
                                <label class="label-checkbox" for="coding">Special Code</label>
                            </div>
                        </div>
                        </div>
                        <div class="confirmation">
                            <h5 class="product-name" data-toggle="collapse" data-target="#payment_collapse" aria-expanded="false" aria-controls="collapseExample">Order currency<img src="../assets/img/down.svg" alt=""></h5>
                            <div class="collapse collapse-none" id="payment_collapse">
                                <select class="form-select select-order select-price" aria-placeholder="price" aria-label="Default select example" id='prod_valuta' name='currency'>
                                            <?php if(Auth::user()->gel == 1): ?>
                                            <option value="1">gel</option>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->euro == 1): ?>
                                                <option value="2">euro</option>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->usd == 1): ?>
                                                <option value="3">usd</option>
                                            <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="confirmation">
                            <h5 class="product-name" data-toggle="collapse" data-target="#payment_collapse" aria-expanded="false" aria-controls="collapseExample">Payment method <img src="../assets/img/down.svg" alt=""></h5>
                            <div class="collapse collapse-none" id="payment_collapse">
                                <?php if(Auth::user()->tbc_id != null && Auth::user()->tbc_key != null): ?>
                                    <div>
                                        <input type="checkbox" class="tbc-prev" name="tbc" value="1" >
                                        <label class="label-checkbox" for="coding">TBC</label>
                                    </div>
                                <?php endif; ?>
                                <?php if(Auth::user()->payze_id != null && Auth::user()->payze_key != null): ?>
                                    <div>
                                        <input type="checkbox" class="payze-prev" name="payze" value="1" >
                                        <label class="label-checkbox" for="coding">payze</label>
                                    </div>
                                <?php endif; ?>
                                <?php if(Auth::user()->ipay_id != null && Auth::user()->ipay_key != null): ?>
                                    <div>
                                        <input type="checkbox" class="ipay-prev" name="ipay" value="1" >
                                        <label class="label-checkbox" for="coding">ipay</label>
                                    </div>
                                <?php endif; ?>
                                <?php if(Auth::user()->stripe_id != null && Auth::user()->stripe_key != null): ?>
                                    <div>
                                        <input type="checkbox" class="stripe-prev" name="stripe" value="1" >
                                        <label class="label-checkbox" for="coding">stripe</label>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="confirmation">
                        <h5 class="product-name" data-toggle="collapse" data-target="#confirmation_collapse" aria-expanded="false" aria-controls="collapseExample">Confirmation page <img src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="confirmation_collapse">
                            <input type="checkbox" class="hs-7" name="customers_info" value="1" >
                            <label class="label-checkbox " for="coding">customers info</label>
                        </div>
                        </div>
                </div>
                <!-- preview -->
                <div class="col-12 col-lg-7 pages1">
                        <h5 class="product-name">Product</h5>
                        <div class="flex previews row">
                            <div class="col-9 flex">
                                <a href="">
                                <h5 class="preview-pages">Payment Page</h5>
                                </a>
                            </div>
                            <div class="col-3 responsive-button">
                                <div class="  buttons flex">
                                <i class="fas fa-mobile-alt" id="mobile"></i>
                                <i class="fas fa-desktop " id="desktop"></i>
                                </div>
                            </div>
                        </div>
                        <!-- preview-page -->
                        <div class="preview">
                            <div class="row product-row">
                                <div class="col-12 col-md-7 products" id='preview_page'>
                                    <div id="nano" >
                                    </div>
                                </div>
                                <div class="col-12 col-md-5 price1">
                                    <div class="price">
                                        <h6 class="total-price"  id='total_str'>სულ:</h6>

                                    </div>
                                    <button class="btn pay-btn" type="submit" >Pay</button>
                                </div>
                                <div class="opt-div row">
                                    
                                    <div class="col-12 col-md-6 h-1 hidden-spec">
                                        <input type="text" placeholder="full name"  class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 h-2 hidden-spec">
                                        <input type="text" placeholder="telephone" class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 h-3 hidden-spec">
                                        <input type="text" placeholder="address" class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 h-4 hidden-spec">
                                        <input type="text" placeholder="email" class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 h-5 hidden-spec">
                                        <input type="text" placeholder="Id number" class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 h-6 hidden-spec">
                                        <input type="text" placeholder="Special code" class="form-control">
                                    </div>
                                    <div class="col-12  h-7 hidden-spec">
                                        <textarea class="form-control cust"  rows="3" placeholder="customers info"></textarea>
                                    </div>
                                </div>
                                <div class="d-block">
                                    <h5 class="product-name pay-method">Payment methods</h5>
                                    <div class="bank-form flex">
                                        <div id="tbc_prev" class="bank-item">
                                            <img src="../assets/img/tbc.png" alt="">
                                        </div>
                                        <div id="payze_prev" class="bank-item">
                                            <img src="../assets/img/payze.png" alt="">
                                        </div>
                                        <div id="stripe_prev" class="bank-item">
                                            <img src="../assets/img/stripe.png" alt="">
                                        </div>
                                        <div id="ipay_prev" class="bank-item">
                                            <img src="../assets/img/ipay.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="special_code_div" style='margin:20px; display:none;'>
                                Special Code <input type='text' size=10 name='special_code' id='special_code'>
                            </div>
                        </div>
                </div>
                <hr>
            </div>
        </div>
    </form>
    <?php echo $__env->make('components.add_product_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay - Copy\resources\views/components/invoice.blade.php ENDPATH**/ ?>