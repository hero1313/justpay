<?php $__env->startSection('content'); ?>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">შექმნის თარიღი</th>
        <th scope="col">ფასი</th>
        <th scope="col">ინვოისის ბმული</th>
        <th scope="col">სტატუსი</th>
        <th scope="col">დამატებითი ინფორმაცია</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          if ($order->valuta == 1) {
            $valuta = 'GEL';
          }
          elseif ($order->valuta == 2) {
            $valuta = 'EURO';
          }
          elseif ($order->valuta == 3) {
            $valuta = 'USD';
          }
        ?>
        <tr class="products-tr">
            <th scope="row"><?php echo e($order->created_at); ?></th>
            <td><?php echo e($order->total); ?> <?php echo e($valuta); ?></td>
            <td><a href="/order/<?php echo e($order->front_code); ?>"><?php echo e($url); ?>/order/<?php echo e($order->front_code); ?></a></td>
            <td>
                <?php if($order->status == -1): ?>
                    <button type="button" class="btn btn-danger">ჩაშლილი</button>
                <?php elseif($order->status == 0): ?>
                    <button type="button" class="btn btn-primary">აქტიური</button>
                <?php elseif($order->status == 1): ?>
                    <button type="button" class="btn btn-success">გადახდილი</button>
                <?php endif; ?>
            </td>
            <td><?php echo e($order->description); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/admin/components/orders.blade.php ENDPATH**/ ?>