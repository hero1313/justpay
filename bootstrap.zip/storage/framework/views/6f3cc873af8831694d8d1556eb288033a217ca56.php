<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('stripe.payment')); ?>" method="post">
    <script
        src="https://checkout.stripe.com/checkout.js"
        class="stripe-button"
        data-key="pk_test_51LTMwVFPefbRqaCagR6ohCK2mT45sLAIluvxN3Ej03DNce9A8cx3Zy3ZkUS7sPW0982St2YKoq5STOcg4UwUen0V00r7gDDlu7"
        data-name="T-shirt"
        data-description="Comfortable cotton t-shirt"
        data-amount="500"
        data-currency="usd">
  </script>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/stripe/form.blade.php ENDPATH**/ ?>