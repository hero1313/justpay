<?php $__env->startSection('content'); ?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


    <button type="button" class="btn btn-dark mb-4" data-toggle="modal" data-target="#addProductModal">
        <?php echo app('translator')->get('public.add_product'); ?>
    </button>

    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col"><?php echo app('translator')->get('public.id'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.image'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.name'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.code'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.price'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.description'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($products) && $products->count()): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="products-tr">
                        <th scope="row"><?php echo e($product->id); ?></th>
                        <td><img src="assets/image/<?php echo e($product->image); ?>" alt=""></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->code); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td>
                            <form id="delete-form" action="remove-save-product/<?php echo e($product->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button class="btn btn-danger" type="submit"><?php echo app('translator')->get('public.delete'); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="10">
                        <div><?php echo $products->appends(Request::all())->links(); ?></div>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductModal"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form action="add-product" method="POST" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="add">
                            <h5 class="product-name order-product"><?php echo app('translator')->get('public.add_new'); ?></h5>
                            <h6 class="pre-text"><?php echo app('translator')->get('public.provide'); ?></h6>
                            <hr>
                            <div class="row order-info">
                                <div class="col-12 col-lg-6">
                                    <div>
                                        <h5 class="product-name order-product"><?php echo app('translator')->get('public.product'); ?></h5>
                                        <input type="text" name='name' class="form-control order-input prod-name">
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product"><?php echo app('translator')->get('public.description'); ?></h5>
                                        <textarea class="form-control order-input textarea-order" id='prod_desc' name='description'></textarea>
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product"><?php echo app('translator')->get('public.code'); ?></h5>
                                        <input type="text" name='code' class="form-control order-input prod-name">
                                    </div>
                                    <div>
                                        <h5 class="product-name order-product"><?php echo app('translator')->get('public.price'); ?></h5>
                                        <div class="flex price-4">
                                            <input type="number" class="form-control order-input input-price"
                                                id='prod_price' name='price' step="0.01">
                                            <select class="form-select select-order select-price" aria-placeholder="price"
                                                aria-label="Default select example" id='prod_valuta' name='currency'>
                                                <?php if(Auth::user()->gel == 1): ?>
                                                    <option value="1">gel</option>
                                                <?php endif; ?>
                                                <?php if(Auth::user()->euro == 1): ?>
                                                    <option value="2">euro</option>
                                                <?php endif; ?>
                                                <?php if(Auth::user()->usd == 1): ?>
                                                    <option value="3">usd</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <div class="upload-img">
                                        <h5 class="product-name order-product"><?php echo app('translator')->get('public.image'); ?></h5>
                                        <input type="file" class="image-input" name="image">
                                    </div>
                                    <img src='' id='review_image'>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('public.close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('public.add_product'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <?php if($errors->any()): ?>
        <script>
            swal("<?php echo e($errors->first()); ?>", "", "error");
        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/site/public/resources/views/components/products.blade.php ENDPATH**/ ?>