<?php $__env->startSection('content'); ?>


    <style>
        .menu {
            display: none;
        }
        button{
            display: none !important;
        }
    </style>
    <script>
        Swal.fire({
  icon: 'success',
  title: 'გადარიცხვის მოთხოვნა მიღებულია',
  text: '',
  footer: '<a href="https://onpay.cloud/landing-page">მთავარ გვერდზე დაბრუნება</a>'
})
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/components/open-msg.blade.php ENDPATH**/ ?>