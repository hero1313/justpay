<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col"><?php echo app('translator')->get('public.create_date'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.name'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.price'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.invoice_link'); ?></th>
                <th scope="col"><?php echo app('translator')->get('public.status'); ?></th>
                <th></th>
                <th scope="col"><?php echo app('translator')->get('public.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($orders) && $orders->count()): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="products-tr">
                        <th scope="row"><?php echo e($order->created_at); ?></th>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->total); ?></td>
                        <td><a href="/order/<?php echo e($order->front_code); ?>"><?php echo e($url); ?>/order/<?php echo e($order->front_code); ?></a>
                        </td>
                        <td>
                            <?php if($order->status == -1): ?>
                                <button type="button" class="btn btn-danger"><?php echo app('translator')->get('public.canceled'); ?></button>
                            <?php elseif($order->status == 0): ?>
                                <button type="button" class="btn btn-primary"><?php echo app('translator')->get('public.active'); ?></button>
                            <?php elseif($order->status == 1): ?>
                                <button type="button" class="btn btn-success"><?php echo app('translator')->get('public.payed'); ?></button>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="order-link-div d-flex">
                                <input class="link-input" type="number" placeholder="ნომერი" id="sms_input_<?php echo e($order->id); ?>">
                                <button class="btn ml-2" id="sms_button" onclick="sendSms(<?php echo e($order->id); ?>)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#00000"
                                        class="bi bi-envelope" viewBox="0 0 16 16">
                                        <path
                                            d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z" />
                                    </svg>
                                </button>
                            </div>
                        </td>
                        <td>
                            <form id="delete-form" action="remove-invoice/<?php echo e($order->id); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" type="submit"><?php echo app('translator')->get('public.delete'); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="10">
                        <div><?php echo $orders->appends(Request::all())->links(); ?></div>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="10">There are no data.</td>
                </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <script>
        function sendSms($id) {
            var number = $("#sms_input_"+ $id).val();
            $.ajax({
                type: 'get',
                url: '<?php echo e(url('/sms-link')); ?>',
                data: {
                    'number': number,
                    'order_id': $id
                },
                success: function(response) {
                    Swal.fire(
                        'შეტყობინება წარმატებით გაიგზავნა!',
                        '',
                        'success'
                    )
                }
            })

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/components/orders.blade.php ENDPATH**/ ?>