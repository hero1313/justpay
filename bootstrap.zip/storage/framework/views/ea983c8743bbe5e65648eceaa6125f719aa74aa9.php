<?php $__env->startSection('content'); ?>

    <div class="container">
        <h4 class="link-number"><?php echo app('translator')->get('public.transaction'); ?> #<?php echo e($order->id); ?></h4>
        <div class="products-list">
            <h6 class="link-prod-title"><?php echo app('translator')->get('public.products'); ?></h6>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex pay-order-div mb-3">
                    <img src="../assets/image/<?php echo e($product->image); ?>" alt="">
                    <div>
                        <h6><?php echo e($product->name); ?></h6>
                        <h6 class="link-prod-price"><?php echo e($product->price); ?>

                            <?php if($product->currency == 1): ?>
                            GEL
                            <?php elseif($product->currency == 2): ?>
                                EURO
                            <?php elseif($product->currency == 3): ?>
                                USD
                            <?php endif; ?>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script>
        function myFunction() {
        var copyText = document.getElementById("myInput");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/site/public/resources/views/components/transaction_item.blade.php ENDPATH**/ ?>