
<?php $__env->startSection('content'); ?>
    <div class="col-12 main-transaction">
        <div class="text-nowrap overflow-none">
            <div class="reports-filter row">
                <div class="col-12 col-md-6">
                    <form class="" action="">
                        <div class="flex">
                            <div>
                                <label for=""><?php echo app('translator')->get('public.start_date'); ?></label>
                                <input class="form-control" type="date" value="<?php echo e($first_date); ?>" name="first_date">
                            </div>
                            <div>
                                <label for=""><?php echo app('translator')->get('public.end_date'); ?></label>
                                <input class="form-control" type="date" value="<?php echo e($second_date); ?>" name="second_date">
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit"><?php echo app('translator')->get('public.filter'); ?></button>
                    </form>
                </div>
                <div class="col-12 col-md-3">
                    <button class="btn btn-success"><?php echo app('translator')->get('public.income'); ?> : <?php echo e($total); ?></button>
                </div>
                <div class="col-12 col-md-3">
                    <div class="dropdown w-100">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo app('translator')->get('public.sort'); ?>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                            <button class="dropdown-item display-invoice" type="button"><?php echo app('translator')->get('public.as_invoices'); ?></button>
                            <button class="dropdown-item display-product" type="display-product"><?php echo app('translator')->get('public.as_products'); ?></button>
                        </div>
                    </div>
                </div>
                <a href="/export"><button class="btn btn-success mt-4"><?php echo app('translator')->get('public.export_excel'); ?></button></a>

            </div>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $invoices = DB::table('orders')
                        ->where('id', '=', $transaction->order_id)
                        ->get();
                    $products = DB::table('products')
                        ->where('order_id', '=', $transaction->order_id)
                        ->get();
                    
                ?>

                <div class="products-report">
                    <div class="mb-3 reports-container">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex pay-order-div reports-product mb-3">
                                <img src="../assets/image/<?php echo e($product->image); ?>" alt="">
                                <div class="ml-3">
                                    <h6><?php echo e($product->name); ?></h6>
                                    <h6 class="link-prod-price"><?php echo e($product->price); ?>

                                        <?php if($product->currency == 1): ?>
                                            GEL
                                        <?php elseif($product->currency == 2): ?>
                                            EURO
                                        <?php elseif($product->currency == 3): ?>
                                            USD
                                        <?php endif; ?>
                                    </h6>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php $__currentLoopData = $invoices_n; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // აქ უნდა გავითვალისწინოთ რომ პირველ პირობაში
                    // ეს ტრანზაქვიები უნდა იყოს სტატუსით წარმატებული
                    // და მეორე პირობაშიც იგივე
                    $trans_count = DB::table('transactions')
                        ->where('order_id', '=', $invoice->id)
                        ->where('user_id', '=', Auth::user()->id)
                        ->where('transaction_status', '=', 1)
                        ->count();
                    $transactions = DB::table('transactions')
                        ->where('order_id', '=', $invoice->id)
                        ->where('user_id', '=', Auth::user()->id)
                        ->where('transaction_status', '=', 1)
                        ->get();
                    $products = DB::table('products')
                        ->where('order_id', '=', $invoice->id)
                        ->where('user_id', '=', Auth::user()->id)
                        ->get();
                    
                    if ($first_date) {
                        $trans_count = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '>', $first_date)
                            ->count();
                        $transactions = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '>', $first_date)
                            ->get();
                    }
                    if ($second_date) {
                        $trans_count = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '<', $second_date)
                            ->count();
                        $transactions = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '<', $second_date)
                            ->get();
                    }
                    if ($second_date && $first_date) {
                        $trans_count = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '<', $second_date)
                            ->where('created_at', '>', $first_date)
                            ->count();
                        $transactions = DB::table('transactions')
                            ->where('transaction_status', '=', 1)
                            ->where('order_id', '=', $invoice->id)
                            ->where('user_id', '=', Auth::user()->id)
                            ->where('created_at', '<', $second_date)
                            ->where('created_at', '>', $first_date)
                            ->get();
                    }
                ?>

                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="invoice-report">
                        <div class="row invoice-row" data-toggle="collapse" data-target="#<?php echo e($invoice->id); ?>"
                            aria-expanded="false" aria-controls="collapseExample">
                            <div class="col-12 col-md-4"><?php echo e($invoice->name); ?></div>
                            <div class=" col-12 col-md-2"><?php echo e($invoice->total); ?></div>
                            <div class=" col-12 col-md-1">
                                <?php if($invoice->valuta == 1): ?>
                                    GEL
                                <?php elseif($invoice->valuta == 2): ?>
                                    EURO
                                <?php elseif($invoice->valuta == 3): ?>
                                    USDs
                                <?php endif; ?>
                            </div>
                            <div class="col-5"><a
                                    href="/order/<?php echo e($invoice->front_code); ?>"><?php echo e($url); ?>/order/<?php echo e($invoice->front_code); ?></a>
                            </div>
                        </div>
                        <div class="collapse" id="<?php echo e($invoice->id); ?>">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex pay-order-div mb-3">
                                    <img src="../assets/image/<?php echo e($product->image); ?>" alt="">
                                    <div class="ml-3">
                                        <h6><?php echo e($product->name); ?></h6>
                                        <h6 class="link-prod-price"><?php echo e($product->price); ?>

                                            <?php if($product->currency == 1): ?>
                                                GEL
                                            <?php elseif($product->currency == 2): ?>
                                                EURO
                                            <?php elseif($product->currency == 3): ?>
                                                USD
                                            <?php endif; ?>
                                        </h6>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row reports-transaction">
                                    <div class="col-12 col-md-6">
                                        <a href="transaction/<?php echo e($transaction->id); ?>"><?php echo e($transaction->pay_id); ?></a>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <?php echo e($transaction->total); ?>

                                        <?php if($transaction->valuta == 1): ?>
                                            GEL
                                        <?php elseif($transaction->valuta == 2): ?>
                                            EURO
                                        <?php elseif($transaction->valuta == 3): ?>
                                            USD
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <?php if($transaction->pay_method == 1): ?>
                                            TBC PAY
                                        <?php elseif($transaction->pay_method == 2): ?>
                                            IPAY
                                        <?php elseif($transaction->pay_method == 3): ?>
                                            STRIPE
                                        <?php elseif($transaction->pay_method == 4): ?>
                                            PAYZE
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <?php echo e($transaction->created_at); ?>

                                    </div>
                                    <?php if($transaction->full_name): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->full_name); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($transaction->number): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->number); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($transaction->email): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->email); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($transaction->id_number): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->id_number); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($transaction->special_code): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->special_code); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if($transaction->address): ?>
                                        <div class="col-12 col-md-6">
                                            <?php echo e($transaction->address); ?>

                                        </div>
                                        <hr>
                                        <div class="col-6">
                                            <iframe
                                                src="https://maps.google.com/maps?q=<?php echo e($transaction->lat); ?>,<?php echo e($transaction->lng); ?>&t=&z=15&ie=UTF8&iwloc=&output=embed"></iframe>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/components/reports.blade.php ENDPATH**/ ?>