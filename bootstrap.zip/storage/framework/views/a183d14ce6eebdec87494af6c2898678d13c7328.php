    <a class="menu-item flex " href='../invoice'>
        <div class="flex item2 menu-product "><i class="fas fa-shopping-cart svg"></i><h6 class="product-name1"><?php echo app('translator')->get('public.invoice'); ?></h6></div>
    </a>
    <a class="menu-item flex "  href='<?php echo e(route('products.show')); ?>'>
        <div class="flex item2 menu-product "><i class="fas fa-tshirt svg"></i><h6 class="product-name1"><?php echo app('translator')->get('public.products'); ?></h6></div>
    </a>
    <a class="menu-item flex "  href='<?php echo e(route('order.show_table')); ?>'>
        <div class="flex item2 menu-orders "><i class="far svg fa-clock"></i> <h6 class="product-name1"><?php echo app('translator')->get('public.orders'); ?></h6></div>
    </a>

    <div class="menu-item flex ">
        <a class="flex item2 menu-transaction "  href='<?php echo e(route('transactions.index')); ?>'><i class="fas fa-exchange-alt svg"></i> <h6 class="product-name1"><?php echo app('translator')->get('public.transactions'); ?></h6></a>
    </div>
    <div class="menu-item flex ">
        <a class="flex item2 menu-parameter " href='/setting'><i class="fas fa-cogs svg"></i> <h6 class="product-name1"><?php echo app('translator')->get('public.settings'); ?></h6></a>
    </div>
    <a class="menu-item flex " href='/logout'>
        <div class="flex item2  menu-login" ><i class="far fa-user svg"></i> <h6 class="product-name1"><?php echo app('translator')->get('public.Logout'); ?></h6></div>
    </a>
    <br>
    <div class="dropdown ml-2">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo e(Config::get('app.locale')); ?>

        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
          <a class="dropdown-item" href="locale/en">en</a>
          <a class="dropdown-item" href="locale/ge">ge</a>
        </div>
      </div>
<?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>