<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="preview-order container">
    <div class="row">
        <div class="col-12 col-md-6">
            <section class="brand-section d-flex">
                <img src="../assets/image/<?php echo e($company->profile_photo_path); ?>" alt="">
                <h4><?php echo e($company->name); ?></h4>
            </section>
            <section class="preview-products">
                <table class="table preview-table">
                    <thead>
                      <tr class="preview-thead-tr">
                        <th ><?php echo app('translator')->get('public.product'); ?></th>
                        <th ><?php echo app('translator')->get('public.quantity'); ?></th>
                        <th ><?php echo app('translator')->get('public.price'); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="preview-tr">
                                <td>
                                    <div class="prod-img d-flex">
                                        <img src="../assets/image/<?php echo e($product->image); ?>" alt="">
                                        <h6><?php echo e($product->name); ?></h6>
                                    </div>
                                </td>
                                <td>
                                    <h6 class="preview-quantity"><?php echo e($product->amount); ?></h6>
                                </td>
                                <td>
                                    <h6 class="preview-price"><?php echo e($product->price); ?>

                                        <?php if($product->currency == 1): ?>
                                            GEL
                                        <?php elseif($product->currency == 2): ?>
                                            EURO
                                        <?php elseif($product->currency == 3): ?>
                                            USD
                                        <?php endif; ?>
                                    </h6>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
            </section>
            <section class="preview-total">
                <div class="d-flex">
                    <h5 class="preview-subtotal"><?php echo app('translator')->get('public.subtotal'); ?></h5>
                    <h5><?php echo e($subtotal); ?> <?php echo e($currency); ?></h5>
                </div>
                <div class="d-flex">
                    <h5 class="preview-subtotal"><?php echo app('translator')->get('public.shiping_price'); ?></h5>
                    <h5>
                        <?php if($order->shiping != 0): ?>
                            <?php echo e($order->shiping); ?> <?php echo e($currency); ?>

                        <?php else: ?>
                            <?php echo app('translator')->get('public.free'); ?>
                        <?php endif; ?>
                    </h5>
                </div>
                <hr>
                <div class="d-flex">
                    <h4 class="preview-total-h4"><?php echo app('translator')->get('public.total'); ?></h4>
                    <h4><?php echo e($order->total); ?> <?php echo e($currency); ?></h4>
                </div>
            </section>
        </div>
        <div class="col-12 col-md-6">
            <form  id="sub">
                <h5 class="contact-info"><?php echo app('translator')->get('public.contact_info'); ?></h5>
                <div class="opt-div opt-div-order row ">
                    <?php if($order->full_name == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.full_name'); ?>" name = 'name' class="  form-control" >
                        </div>
                    <?php endif; ?>
                    <?php if($order->number == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.number'); ?>" name = 'number' class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->address == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.address'); ?>" name = 'address' class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->email == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" name="email" placeholder="<?php echo app('translator')->get('public.email'); ?>" class=" form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->id_number == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.id_number'); ?>" name="id_number" class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->special_code == 1): ?>
                        <div class="col-12 col-md-6">
                            <input type="text" placeholder="<?php echo app('translator')->get('public.special_code'); ?>" name="special_code" class="  form-control">
                        </div>
                    <?php endif; ?>
                    <?php if($order->description == 1): ?>
                        <div class="col-12 ">
                            <textarea class="form-control textarea-order"  rows="3" placeholder="<?php echo app('translator')->get('public.customers_info'); ?>"></textarea>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
            <div class="d-block mt-4">
                <h5 class="contact-info mb-4"><?php echo app('translator')->get('public.pay_method'); ?></h5>
                <div class="bank-form flex">
                    <?php if($order->tbc == 1): ?>
                        <div id="tbc_prev" class="bank-item-order">
                                <img src="../assets/img/tbc.png" alt="">
                        </div>
                    <?php endif; ?>
                    <?php if($order->stripe == 1): ?>
                            <script
                                src="https://checkout.stripe.com/checkout.js"
                                class="stripe-button"
                                data-key="pk_test_51LTMwVFPefbRqaCagR6ohCK2mT45sLAIluvxN3Ej03DNce9A8cx3Zy3ZkUS7sPW0982St2YKoq5STOcg4UwUen0V00r7gDDlu7"
                                data-name="T-shirt"
                                data-description="Comfortable cotton t-shirt"
                                data-amount="500"
                                data-currency="usd"
                                data-label="Subscribe">
                          </script>
                    <?php endif; ?>
                    <?php if($order->payze == 1): ?>
                        <a href="">
                            <div id="payze_prev" class="bank-item-order">
                                <img src="../assets/img/payze.png" alt="">
                            </div>
                        </a>
                    <?php endif; ?>
                    <?php if($order->ipay == 1): ?>
                        <a href="<?php echo e(route("tbcpayment, ['status' => 1]")); ?>">
                            <div id="ipay_prev" class="bank-item-order">
                                <img src="../assets/img/ipay.jpg" alt="">
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $( "#tbc_prev" ).click(function() {
       $('#sub').attr('action',"<?php echo e(route('tbcpayment', ['frontId' => $order->front_code])); ?>");
       $('#sub').submit();
   });
</script>
<?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/components/order_view.blade.php ENDPATH**/ ?>