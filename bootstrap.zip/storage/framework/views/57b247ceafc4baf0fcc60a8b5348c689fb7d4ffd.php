<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<title> <?php echo $__env->yieldContent('title'); ?> - Deliveron</title>
        
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="/css/bpg-arial-caps.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <?php echo $__env->yieldContent('include'); ?>
    </head>
    <body id="appbody">


            <!-- Page Heading -->
           

            <!-- Page Content -->

			

    </body>
</html>
<?php /**PATH /home/justpay/site/public/resources/views/layouts/app.blade.php ENDPATH**/ ?>