<div class="cover">

</div>
<div class="hidden-nav">
    <div>
        <img class="x" src="../assets/img/x.svg" alt="">
    </div>
    <a class="menu-item flex " href='/invoice'>
        <div class="flex item2 menu-product "><i class="fas fa-shopping-cart svg"></i><h6 class="product-name1">Invoice</h6></div>
    </a>
    <a class="menu-item flex "  href='<?php echo e(route('products.show')); ?>'>
        <div class="flex item2 menu-product "><i class="fas fa-tshirt svg"></i><h6 class="product-name1">Products</h6></div>
    </a>
    <a class="menu-item flex "  href='<?php echo e(route('order.show_table')); ?>'>
        <div class="flex item2 menu-orders "><i class="far svg fa-clock"></i> <h6 class="product-name1">Orders</h6></div>
    </a>

    <div class="menu-item flex ">
        <a class="flex item2 menu-transaction "  href='<?php echo e(route('transactions.index')); ?>'><i class="fas fa-exchange-alt svg"></i> <h6 class="product-name1">Transactions</h6></a>
    </div>
    <div class="menu-item flex ">
        <a class="flex item2 menu-parameter " href='/setting'><i class="fas fa-cogs svg"></i> <h6 class="product-name1">Settings</h6></a>
    </div>
    <a class="menu-item flex " href='/logout'>
        <div class="flex item2  menu-login" ><i class="far fa-user svg"></i> <h6 class="product-name1">Logout</h6></div>
    </a>

</div>
<?php /**PATH C:\Users\Admin\Desktop\justpay - Copy\resources\views/layouts/hidden-nav.blade.php ENDPATH**/ ?>