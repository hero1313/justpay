<?php $__env->startSection('content'); ?>
<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Id</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Number</th>
        <th scope="col">Identity number</th>
        <th scope="col">Bank Code</th>
        <th scope="col">Tbc</th>
        <th scope="col">Ipay</th>
        <th scope="col">Payze</th>
        <th scope="col">Stripe</th>
        <th scope="col">percent</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $merchants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="products-tr">
            <th scope="row"><?php echo e($merchant->id); ?></th>
            <td><a href="/admin/merchant/<?php echo e($merchant->id); ?>"><?php echo e($merchant->name); ?></a></td>
            <td><?php echo e($merchant->email); ?></td>
            <td><?php echo e($merchant->number); ?></td>
            <td><?php echo e($merchant->identity_number); ?></td>
            <td><?php echo e($merchant->bank_code); ?></td>
            <td><?php echo e($merchant->tbc); ?></td>
            <td><?php echo e($merchant->ipay); ?></td>
            <td><?php echo e($merchant->payze); ?></td>
            <td><?php echo e($merchant->stripe); ?></td>
            <td><?php echo e($merchant->percent); ?>%</td>
            <td></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/admin/components/merchants.blade.php ENDPATH**/ ?>