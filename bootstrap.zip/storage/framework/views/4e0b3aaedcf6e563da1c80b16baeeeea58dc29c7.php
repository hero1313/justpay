<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: '<?php echo e($error); ?>',
                })
            </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form class="product-form" id="invoice_form" action='<?php echo e(route('store.order')); ?>' enctype='multipart/form-data'
        method="POST">
        <?php echo csrf_field(); ?>
        <div class="col-12 main-product">
            <div class="row main-row">
                <div class="col-12   col-lg-4 pages">
                    <h5 class="product-name"><?php echo app('translator')->get('public.add_product'); ?></h5>
                    <div class="col-9  input-name2 ">
                        <button type="button" class="btn new-product-btn" data-toggle="modal"
                            data-target="#exampleModalCenter">
                            <?php echo app('translator')->get('public.add_product'); ?>
                        </button>
                    </div>
                    <br>
                    <div class="form-group mt-3">
                        <h5 class="product-name" data-toggle="collapse" data-target="#name_collapse" aria-expanded="false"
                            aria-controls="collapseExample"><?php echo app('translator')->get('public.invoice_name'); ?><img src="../assets/img/down.svg"
                                alt=""></h5>
                        <input type="text" id="name_collapse" class="form-control invoice-name" required
                            name="invoice_name">
                    </div>
                    <div class="invoice_type">
                        <h5 class="product-name" data-toggle="collapse" data-target="#invoice_type_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.invoice_type'); ?> <img
                                src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="invoice_type_collapse">
                            <div class="radio-container col-11">
                                <input type="radio" id="inv_type1" name="inv_type" value="1" checked
                                    onchange='preview_products();'>
                                <label class="label-checkbox" for="inv_type1"><?php echo app('translator')->get('public.one_time'); ?> </label><button
                                    class="btn btn-one d-none" data-toggle="tooltip" data-placement="top"
                                    title="აქ რასაც გვინდა ჭავწერთ">?</button>
                                <br>
                                <input type="radio" id="inv_typ2" name="inv_type" value="2"
                                    onchange='preview_products();'>
                                <label for="inv_type2"><?php echo app('translator')->get('public.multi_order'); ?></label><button class="btn btn-one d-none"
                                    data-toggle="tooltip" data-placement="top" title="აქ რასაც გვინდა ჭავწერთ">?</button>
                            </div>
                        </div>
                    </div>
                    <div class="payment">
                        <h5 class="product-name " data-toggle="collapse" data-target="#requirements_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.payment_requirements'); ?><img
                                src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="requirements_collapse">
                            <div class="form-check form-switch">
                                <input type="checkbox" class="hs-1 form-check-input" name="fullname" value="1"
                                    id='req_fname_ch'>
                                <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.full_name'); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox"class="hs-2 form-check-input" name="telephone" value="1"
                                    id='req_tel_ch'>
                                <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.telephone'); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox" class="hs-3 form-check-input" name="address" value="1"
                                    id='req_addr_ch'>
                                <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.address'); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox" class="hs-4 form-check-input" name="email" value="1"
                                    id='req_email_ch'>
                                <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.email'); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox" class="hs-5 form-check-input" name="id_number" value="1"
                                    id='req_id_ch'>
                                <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.id_number'); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox" class="hs-6 form-check-input" name="spec_code" value="1"
                                    id='req_code_ch'>
                                <label class="label-checkbox" for="coding"><?php echo app('translator')->get('public.special_code'); ?></label>
                            </div>
                        </div>
                    </div>
                    <div class="confirmation">
                        <h5 class="product-name" data-toggle="collapse" data-target="#curency_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.currency'); ?><img
                                src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="curency_collapse">
                            <select class="form-select select-order select-price" aria-placeholder="price"
                                aria-label="Default select example" id='prod_valuta' name='currency'>
                                <?php if(Auth::user()->gel == 1): ?>
                                    <option value="1">gel</option>
                                <?php endif; ?>
                                <?php if(Auth::user()->euro == 1): ?>
                                    <option value="2">euro</option>
                                <?php endif; ?>
                                <?php if(Auth::user()->usd == 1): ?>
                                    <option value="3">usd</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <h5 class="product-name" data-toggle="collapse" data-target="#shiping_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.shiping_price'); ?><img
                                src="../assets/img/down.svg" alt=""></h5>
                        <input type="number" id="shiping_collapse" class="form-control shiping" value="0"
                            name="shiping">
                    </div>
                    <div class="confirmation">
                        <h5 class="product-name" data-toggle="collapse" data-target="#payment_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.pay_method'); ?><img
                                src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-none" id="payment_collapse">
                            <?php if(Auth::user()->tbc_id != null && Auth::user()->tbc_key != null): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" id="tbc_checkbox" class="tbc-prev form-check-input"
                                        name="tbc" value="1">
                                    <label class="label-checkbox" for="coding">TBC</label>
                                </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->payze_id != null && Auth::user()->payze_key != null): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" id="payze_checkbox" class="payze-prev form-check-input"
                                        name="payze" value="1">
                                    <label class="label-checkbox" for="coding">payze</label>
                                </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->payriff_id != null && Auth::user()->payriff_key != null): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" id="payriff_checkbox" class="payriff-prev form-check-input"
                                        name="payriff" value="1">
                                    <label class="label-checkbox" for="coding">PAYRIFF</label>
                                </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->ipay_id != null && Auth::user()->ipay_key != null): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" id="ipay_checkbox" class="ipay-prev form-check-input"
                                        name="ipay" value="1">
                                    <label class="label-checkbox" for="coding">ipay</label>
                                </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->stripe_id != null && Auth::user()->stripe_key != null): ?>
                                <div class="form-check form-switch">
                                    <input type="checkbox" id="stripe_checkbox" class="stripe-prev form-check-input"
                                        name="stripe" value="1">
                                    <label class="label-checkbox" for="coding">stripe</label>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="confirmation">
                        <h5 class="product-name" data-toggle="collapse" data-target="#confirmation_collapse"
                            aria-expanded="false" aria-controls="collapseExample"><?php echo app('translator')->get('public.confirmation_page'); ?><img
                                src="../assets/img/down.svg" alt=""></h5>
                        <div class="collapse collapse-non d-block form-check form-switch" id="confirmation_collapse">
                            <input type="checkbox" class="hs-7 form-check-input" name="customers_info" value="1">
                            <label class="label-checkbox " for="coding"><?php echo app('translator')->get('public.colect'); ?></label>
                        </div>
                    </div>
                </div>
                <!-- preview -->
                <div class="col-12 col-lg-8 pages1 ">
                    <h5 class="product-name"><?php echo app('translator')->get('public.product'); ?></h5>
                    <div class="flex previews row">
                        <div class="col-9 flex">
                            <a href="">
                                <h5 class="preview-pages"><?php echo app('translator')->get('public.pay_page'); ?></h5>
                            </a>
                        </div>
                        <div class="col-3 responsive-button">
                            <div class="  buttons flex">
                                <i class="fas fa-mobile-alt" id="mobile"></i>
                                <i class="fas fa-desktop " id="desktop"></i>
                            </div>
                        </div>
                    </div>
                    <div class="preview-order container sub-prev">
                        <div class="row">
                            <div class="col-12 col-md-7 products">
                                <section class="brand-section d-flex">
                                    <img src="../assets/image/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="">
                                    <h4><?php echo e(Auth::user()->name); ?></h4>
                                </section>
                                <section class="preview-products">
                                    <div class="table preview-table mb-2">
                                        <div>
                                            <div class="preview-thead-tr d-flex">
                                                <div class="th-1"><?php echo app('translator')->get('public.product'); ?></div>
                                                <div class="th-2"><?php echo app('translator')->get('public.quantity'); ?></div>
                                                <div class="th-3"><?php echo app('translator')->get('public.price'); ?></div>
                                                <div class="th-0"></div>
                                            </div>
                                        </div>
                                        <div id="nano">
                                        </div>
                                    </div>
                                </section>
                                <section class="preview-total">
                                    <div class="d-flex">
                                        <h5 class="preview-subtotal"><?php echo app('translator')->get('public.subtotal'); ?></h5>
                                        <h5 class="total-price" id='total_str'></h5>
                                    </div>
                                    <div class="d-flex">
                                        <h5 class="preview-subtotal"><?php echo app('translator')->get('public.shiping_price'); ?></h5>
                                        <h5>
                                        </h5>
                                    </div>
                                    <hr>
                                    <div class="d-flex">
                                        <h4 class="preview-total-h4"><?php echo app('translator')->get('public.total'); ?></h4>
                                        <h4></h4>
                                    </div>

                                </section>
                            </div>
                            <div class="col-12 col-md-5 opt price1">
                                <h5 class="contact-info"><?php echo app('translator')->get('public.contact_info'); ?></h5>
                                <div class="opt-div opt-div-order row ">
                                    <div class="opt-div row">
                                        
                                        <div class="col-12 col-md-6 h-1 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.full_name'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12 col-md-6 h-2 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.telephone'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12 col-md-6 h-3 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.address'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12 col-md-6 h-4 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.email'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12 col-md-6 h-5 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.id_number'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12 col-md-6 h-6 hidden-spec">
                                            <input type="text" placeholder="<?php echo app('translator')->get('public.special_code'); ?>" class="form-control">
                                        </div>
                                        <div class="col-12  h-7 hidden-spec">
                                            <textarea class="form-control cust" rows="3" placeholder="<?php echo app('translator')->get('public.customers_info'); ?>"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-block mt-4">
                                    <div class="bank-form flex w-100">
                                        <div class="d-block w-100">
                                            <h5 class="product-name pay-method center"><?php echo app('translator')->get('public.pay'); ?></h5>
                                            <div class="bank-form flex">
                                                <div id="tbc_prev" class="bank-item">
                                                    <img src="../assets/img/tbc.png" alt="">
                                                </div>
                                                <div id="payze_prev" class="bank-item">
                                                    <img src="../assets/img/payze.png" alt="">
                                                </div>
                                                <div id="stripe_prev" class="bank-item">
                                                    <img src="../assets/img/stripe.png" alt="">
                                                </div>
                                                <div id="payriff_prev" class="bank-item">
                                                    <img src="../assets/img/payriff.png" alt="">
                                                </div>
                                                <div id="ipay_prev" class="bank-item">
                                                    <img src="../assets/img/ipay.jpg" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" id="btn_pay" class=" btn btn-pay"><?php echo app('translator')->get('public.create_invoice'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php echo $__env->make('components.add_product_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Auth::user()->sms_name == null && Auth::user()->sms_token == null): ?>
        <script>
            $("#req_tel_ch").click(function() {
                $('#req_tel_ch').prop('checked', false);
                Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'ფუნქციის ჩასართავად გაააქტიურეთ SMS სერვისი ',
                    })
            });
        </script>
    <?php else: ?>
        <script>
            $('.hs-2').change(function() {
                $('.h-2').toggle();
            });
        </script>
    <?php endif; ?>

    <script>
        $(document).ready(function() {
            $("#btn_pay").click(function() {
                if ($("#tbc_checkbox").is(":checked") || $("#payze_checkbox").is(":checked") || $("#payriff_checkbox").is(":checked") || $(
                        "#stripe_checkbox").is(":checked") || $("#ipay_checkbox").is(":checked")) {
                    $('#invoice_form').submit();
                    // alert('122');
                }
                else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: '<?php echo app('translator')->get('public.payment_error'); ?>',
                    })
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/site/public/resources/views/components/invoice.blade.php ENDPATH**/ ?>