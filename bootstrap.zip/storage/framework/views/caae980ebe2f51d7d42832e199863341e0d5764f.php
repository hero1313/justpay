<?php $__env->startSection('content'); ?>
<form action="/opan-banking-pay" method="post">
    <?php echo csrf_field(); ?>
    <div class="bank-container">
        <div class="row bank-accounts-row ">
            <h2>აირჩიეთ ანგარიში</h2>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 ">
                    <div class="bank-div">
                        <div class="form-check">
                            

                            <input class="form-check-input bank-radio" type="radio" value="<?php echo e($account['iban']); ?>"
                                id="checkbox_iban_<?php echo e($loop->index); ?>" name="iban">
                            <label for="checkbox_iban_<?php echo e($loop->index); ?>"><?php echo e($account['iban']); ?></label>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="center">
                <button class="btn btn-main">გაგრძელება</button>
            </div>
        </div>
    </div>
</form>

    <style>
        .bank-accounts-row h2{
            text-align: center;
            margin-bottom: 50px;
        }
        .btn-main{
        background: #fd9157;
        padding: 10px 20px;
        color: #fff;
        font-size: 20px;
        margin-top: 50px;
        }

        .bank-container{
            width: 100vw;
            padding-top: 10vh;

        }
        body{
            background: #f4f4f4;
        }
        .bank-div label{
            margin-bottom: 0px;
        }
        .center{
            text-align: center;
        }
        .menu {
            display: none;
        }

        .bank-accounts-row {
            width: 50%;
            margin: auto;
            background-color: rgb(255, 255, 255);
            min-width: 800px;
            border-radius: 20px;
            padding: 40px 50px;
            box-shadow: 0px 0px 10px 0px rgba(202,202,202,0.75);
        }

        .bank-div {
            padding: 10px;
            background: #ff600a;
            border-radius: 10px;
            color: #fff;
            margin-bottom: 20px;
            font-size: 20px;
            margin-right: 10px;
            margin-left: 10p
        }
    </style>

     

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/components/open-redirect.blade.php ENDPATH**/ ?>