
<?php $__env->startSection('content'); ?>
    <div class="container py-3">
        <?php if($errors->any()): ?>
            <div class="note note-danger mb-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('texts.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="var">Variable</label>
                <input class="form-control" id="var" name="var" value="<?php echo e(old('var')); ?>">
            </div>

            <ul class="nav nav-tabs" role="tablist">
                <?php $__currentLoopData = config('custom_vars.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" data-toggle="tab"
                            href="#tab_<?php echo e($val); ?>" role="tab" aria-controls="tab_<?php echo e($val); ?>"
                            aria-selected="true">
                            <?php echo e($val); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="tab-content px-0 py-2">
                <?php $__currentLoopData = config('custom_vars.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>"
                        id="tab_<?php echo e($val); ?>" role="tabpanel">
                        <div class="form-group mb-3">
                            <label for="<?php echo e($val); ?>">
                                (<?php echo e($val); ?>)
                            </label>
                            <input type="text" class="form-control" name="<?php echo e($val); ?>" id="<?php echo e($val); ?>"
                                value="<?php echo e(old($val)); ?>" />
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="btn btn-green btn-md">Save</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/site/public/resources/views/admin/texts/create.blade.php ENDPATH**/ ?>