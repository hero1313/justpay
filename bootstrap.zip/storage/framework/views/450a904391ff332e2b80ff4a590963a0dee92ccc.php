<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="add">
                    <h5 class="product-name order-product">Add a new product to invoice</h5>
                    <h6 class="pre-text">Provide a few details to save this product for later use</h6>
                    <hr>
                    <div class="row order-info">
                        <div class="col-6">
                            <div class="">
                                <h5 class="product-name order-product">Product</h5>
                                <input type="text" id='prod_name' name='prod_name' class="form-control order-input prod-name" >
                                <input type="text" id='prod_link' name='prod_link' class="form-control order-input" placeholder='or direct product link' >
                                <select class="form-control order-input" placeholder="Find or add product..." name='prod_search' id='prod_search'onchange='search_change();'>
                                    <option value=''>Find or add product...</option>
                                </select>
                            </div>
                            <div class="">
                                <h5 class="product-name order-product">Description</h5>
                                <textarea  class="form-control order-input textarea-order"  id='prod_desc' name='prod_desc'  ></textarea>
                            </div>
                            <div class="">
                                <h5 class="product-name order-product">quantity</h5>
                                <div class="flex price-4">
                                    <input type="number" class="form-control order-input input-price" id='prod_amount' value="1" name='prod_amount'>
                                </div>
                            </div>
                            <div class="">
                                <h5 class="product-name order-product">price</h5>
                                <div class="flex price-4">
                                    <input type="number" class="form-control order-input input-price" id='prod_price'  name='prod_price' >
                                    <select class="form-select select-order select-price" aria-placeholder="price" aria-label="Default select example" id='prod_valuta' name='prod_valuta'>
                                        <?php if(Auth::user()->gel == 1): ?>
                                        <option value="1">gel</option>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->euro == 1): ?>
                                            <option value="2">euro</option>
                                        <?php endif; ?>
                                        <?php if(Auth::user()->usd == 1): ?>
                                            <option value="3">usd</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="flex recurring" style='display:none;'>
                                    <div class="requrring-btn">Requrring</div>
                                    <div class="requrring-btn2">One time</div>
                                </div>
                            </div>
                            <div class="" style='display:none;'>
                                <h5 class="product-name order-product">Include tax in price</h5>
                                <select class="form-select select-order" aria-label="Default select example">
                                    <option selected>Yes</option>
                                    <option value="1">No</option>
                                </select>
                            </div>
                            <div class="" >
                                <h5 class="product-name order-product">Save for future use</h5>
                                <select class="form-select select-order" aria-label="Default select example" id='prod_save' name='prod_save'>
                                    <option value="0" selected >No</option>
                                    <option value='1'>Yes</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="upload-img">
                                <h5 class="product-name order-product">Image</h5>
                                <input type="file" id="image" class="image-input" name="image[]" >
                            </div>
                            <img src='' id='mimage' name='mimage' width=200px>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" id="reset" class="btn btn-primary">add</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Admin\Desktop\justpay - Copy\resources\views/components/add_product_modal.blade.php ENDPATH**/ ?>