<?php $__env->startSection('content'); ?>
    <div class="center merchant-div">
        <img class="merchant-img" src="../../assets/image/<?php echo e($merchant->profile_photo_path); ?>" alt="">
        <h6><?php echo e($merchant->name); ?></h6>
        <h6><?php echo e($merchant->email); ?></h6>
        <h6>შემოსავალი : <?php echo e($total_income); ?></h6>
        <br>
        <h3 class="font-weight-bold mt-3 ">orders</h3>
        <br>
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">შექმნის თარიღი</th>
                <th scope="col">ფასი</th>
                <th scope="col">ინვოისის ბმული</th>
                <th scope="col">სტატუსი</th>
                <th scope="col">დამატებითი ინფორმაცია</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                if ($order->valuta == 1) {
                    $valuta = 'GEL';
                }
                elseif ($order->valuta == 2) {
                    $valuta = 'EURO';
                }
                elseif ($order->valuta == 3) {
                    $valuta = 'USD';
                }
                ?>
                <tr class="products-tr">
                    <th scope="row"><?php echo e($order->created_at); ?></th>
                    <td><?php echo e($order->total); ?> <?php echo e($valuta); ?></td>
                    <td><a href="/order/<?php echo e($order->front_code); ?>"><?php echo e($url); ?>/order/<?php echo e($order->front_code); ?></a></td>
                    <td>
                        <?php if($order->status == -1): ?>
                            <button type="button" class="btn btn-danger">ჩაშლილი</button>
                        <?php elseif($order->status == 0): ?>
                            <button type="button" class="btn btn-primary">აქტიური</button>
                        <?php elseif($order->status == 1): ?>
                            <button type="button" class="btn btn-success">გადახდილი</button>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($order->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <br>
        <h3 class="font-weight-bold mt-3 ">save products</h3>
        <br>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">ID</th>
                <th scope="col">IMAGE</th>
                <th scope="col">NAME</th>
                <th scope="col">PRICE</th>
                <th scope="col">DESCRIPTION</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="products-tr">
                    <th scope="row"><?php echo e($product->id); ?></th>
                    <td><img src="../../assets/image/<?php echo e($product->image); ?>" alt=""></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->description); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\justpay\resources\views/admin/components/merchant-page.blade.php ENDPATH**/ ?>