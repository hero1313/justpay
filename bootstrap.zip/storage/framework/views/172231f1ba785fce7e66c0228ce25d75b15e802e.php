<?php $__env->startSection('content'); ?>
  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">შექმნის თარიღი</th>
        <th scope="col">ტრანზაქციის კოდი</th>
        <th scope="col">ფასი</th>
        <th scope="col">სახელი</th>
        <th scope="col">სტატუსი</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          if ($order->valuta == 1) {
            $valuta = 'GEL';
          }
          elseif ($order->valuta == 2) {
            $valuta = 'EURO';
          }
          elseif ($order->valuta == 3) {
            $valuta = 'USD';
          }
        ?>
        <tr class="products-tr">
            <th scope="row"><?php echo e($order->created_at); ?></th>
            <th scope="row"><?php echo e($order->pay_id); ?></th>

            <td><?php echo e($order->total); ?> <?php echo e($valuta); ?></td>
            <td><?php echo e($order->full_name); ?></td>
            <td>
                <?php if($order->transaction_status == -1): ?>
                    <button type="button" class="btn btn-danger">ჩაშლილი</button>
                <?php elseif($order->transaction_status == 0): ?>
                    <button type="button" class="btn btn-primary">აქტიური</button>
                <?php elseif($order->transaction_status == 1): ?>
                    <button type="button" class="btn btn-success">გადახდილი</button>
                <?php endif; ?>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/justpay/public/resources/views/admin/components/transactions.blade.php ENDPATH**/ ?>