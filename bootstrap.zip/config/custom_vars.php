<?php
return [
    'languages' => [
        'ka', 'en', 'az'
    ]
];
