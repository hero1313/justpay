<?php

namespace App\Payments;

use App\Payments\Payment;
use App\Models\Transaction;

use Exception;

class BOGpayment extends Payment
{
    private Object $processorConfig;
    private String $requestToken;
    protected Int $payment_type = 3;

    private function sendRequest(String $endpoint, String $data, array $headers, String $method)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'http://xs2a-sandbox.bog.ge/0.8/v1/payments/domestic',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_SSLCERT => 'public/public/cert_file.pem',
            CURLOPT_SSLCERTPASSWD => '123456',
            CURLOPT_POSTFIELDS => '{
                "instructedAmount": {
                  "currency": "GEL",
                  "amount": "123.50"
                },
                "debtorAccount": {
                  "iban": "GE00BG0000000000000000"
                },
                "creditorName": "Merchant123",
                "creditorAccount": {
                  "iban": "GE00BG0000000000000001"
                },
                "remittanceInformationUnstructured": "Ref Number Merchant"
              }',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'X-Request-ID: 99391c7e-ad88-49ec-a2ad-99ddcb1f7722',
            ),
        ));

        

        $response = curl_exec($curl);
        $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        dd($status_code);
        echo $response;
    }

    protected function validateConfig(object $config): void
    {
        if (!isset($config->client_id) || empty($config->client_id)) {
            throw new Exception('BOG PAYMENT CONFIG ERROR: No client_id provided.');
        }
        if (!isset($config->secret_key) || empty($config->secret_key)) {
            throw new Exception('BOG PAYMENT CONFIG ERROR: No secret_key provided.');
        }
    }

    protected function prepare(): void
    {
        $this->processorConfig = (object)config('paymentconfigs.bog');
        $basic = base64_encode("{$this->config->client_id}:{$this->config->secret_key}");
        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: ' . 'Basic ' . $basic
        ];
        $body = 'grant_type=client_credentials';
        $tokenRequest = $this->sendRequest("oauth2/token", $body, $headers, "POST");
        if (!$tokenRequest) {
            throw new Exception('BOG PAYMENT PREPARE ERROR: Unable to get an access token.');
        }
        $this->requestToken = $tokenRequest->result->token_type . " " . $tokenRequest->result->access_token;
    }

    public function createOrder(object $order): object
    {
        $tr_id = Transaction::latest()->pluck('id')->first();
        $tr_id = $tr_id + 1;
        $headers = [
            'Content-Type: application/json',
            'Authorization: ' . $this->requestToken
        ];
        $data = json_encode([
            "instructedAmount" => [
                "currency" => "GEL",
                "amount" => "123.50"
            ],
            "debtorAccount" => [
                "iban" => "GE00BG0000000000000000",
            ],
            "creditorName" => "Merchant123",
            "creditorAccount" => [
                "iban" => "GE00BG0000000000000001",
            ],
            "remittanceInformationUnstructured" => "Ref Number Merchant",
        ]);

        $response = $this->sendRequest('checkout/orders', $data, $headers, "POST");
        $result = (array)$response->result;
        if (!isset($result['status']) || $result['status'] !== 'CREATED') {
            throw new Exception("BOG PAYMENT PAY ERROR: Status is not 'Created', it is: {$result['status']}");
        }
        $links = collect($result['links'])->pluck('href', 'rel');
        if (!isset($links['approve'])) {
            return null;
        }

        return (object)[
            'redirect' => $links['approve'],
            'orderid' => $result['order_id']
        ];
    }


































    public function refund(object $args): void
    {
        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: ' . $this->requestToken
        ];

        $data = http_build_query([
            'order_id' => $args->payId
        ]);

        $result = $this->sendRequest('checkout/refund', $data, $headers, "POST");

        if ($result->httpcode !== 200) {
            throw new Exception("BOG PAYMENT REFUND ERROR: Httpcode is not 200, it is: {$result->httpcode}");
        }
    }

    public function get(object $args): object
    {
        $headers = [
            'Content-Type: application/json',
            'Authorization: ' . $this->requestToken
        ];

        $data = json_encode([]);
        $result = $this->sendRequest("checkout/payment/$args->order_id", $data, $headers, "GET");

        if ($result->httpcode !== 200) {
            throw new Exception("BOG PAYMENT GET ERROR: Httpcode is not 200, it is {$result->httpcode}");
        }
        return $result;
    }

    public function transactionStatus(object $argument): object
    {
        if (!$argument) {
            throw new Exception("BOG PAYMENT getOrderStatus ERROR: Order not set!");
        }

        if (!$argument->payId) {
            throw new Exception("BOG PAYMENT getOrderStatus ERROR: payment_hash not set!");
        }

        $details = $this->get((object) [
            'order_id' => $argument->payId
        ]);
        $response = $details->result;

        return (object)[
            'status' => $response->status,
        ];
    }
}
