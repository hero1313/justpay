<?php
if (!defined('QSEAL_CERT')) define('QSEAL_CERT', __DIR__ . "/certificates/Justpay_Solutions_qseal.pfx");
if (!defined('QSEAL_PASS')) define('QSEAL_PASS', "bog-1234");
if (!defined('QWAC_CERT')) define('QWAC_CERT', __DIR__ . "/certificates/cert_file_qwac.pem");
if (!defined('QWAC_PASS')) define('QWAC_PASS', 123456);