<?php
define("QSEAL_CERT", __DIR__ . "/certificates/Justpay_Solutions_qseal.pfx");
define("QSEAL_PASS", "bog-1234");

define("QWAC_CERT", __DIR__ . "/certificates/cert_file_qwac.pem");
define("QWAC_PASS", 123456);
