<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\SmsUser;
use App\Events\PusherBroadcast;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;


class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $SmsUser = SmsUser::where('company_user_id', '=', Auth::user()->id)->get();

        return view('components.setting', compact(['SmsUser']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Todo  $todo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request){

        $user = User::find(Auth::user()->id);

        $user->name = $request->name;
        $user->email = $request->email;
        $user->number = $request->number;
        $user->identity_number = $request->identity_number;
        $user->address = $request->address;
        $user->bank_code = $request->bank_code;
        $user->account_number = $request->account_number;
        $user->tbc_id = $request->tbc_id;
        $user->payze_id = $request->payze_id;
        $user->stripe_id = $request->stripe_id;
        $user->ipay_id = $request->ipay_id;
        $user->payriff_id = $request->payriff_id;
        $user->tbc_key = $request->tbc_key;
        $user->payze_key = $request->payze_key;
        $user->stripe_key = $request->stripe_key;
        $user->ipay_key = $request->ipay_key;
        $user->payriff_key = $request->payriff_key;
        $user->sms_name = $request->sms_name;
        $user->sms_token = $request->sms_token;
        $user->open_banking_index = $request->open_banking_index;
        $user->open_banking_bog = $request->open_banking_bog;
        $user->open_banking_tbc = $request->open_banking_tbc;
        $user->gel = $request->gel;
        $user->usd = $request->usd;
        $user->euro = $request->euro;
        if($request->hasfile('logo')){
            $destination='assets/image/'.$user->profile_photo_path;
            if(File::exists($destination)){
                File::delete($destination);
            }
            $file = $request->file('logo');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('assets/image/',$filename);
            $user->profile_photo_path = "$filename";
        }

        $user->update();
        return redirect('/setting');
    }
}
