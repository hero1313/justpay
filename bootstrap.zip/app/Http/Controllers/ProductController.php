<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use App\Events\PusherBroadcast;
use App\Exports\ReportExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\File;

class ProductController extends Controller
{
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function export()
    {
        return Excel::download(new ReportExport, 'sales.xlsx');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {        
        $image = new image;
        $image->random_number = $request->random_number;
        if ($request->hasfile('image')) {
            $destination = 'assets/image/' . $image->img;
            if (File::exists($destination)) {
                File::delete($destination);
            }
            $file = $request->file('image');
            $extention = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extention;
            $file->move('assets/image/', $filename);
            $image->img = "$filename";
        }

        $image->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $products = Product::where('user_id', '=', Auth::user()->id)->where('save_index', '=', 1)->orderBy('created_at', 'DESC')->paginate(10);
        return view('components.products', compact(['products']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function remove($id)
    {
        $product = Product::find($id);
        $product->save_index = 0;
        $product->update();
        return back();
    }


    public function addProducts(Request $request)
    {
        if (!$request->currency || !$request->name || !$request->price) {
            return redirect()->back()->withInput($request->input())
                ->withErrors(['msg' => 'გთხოვთ შეავსოთ ყველა ველი']);
        }
        $product = new Product;
        $product->user_id = Auth::user()->id;
        $product->order_id = 0;
        $product->name = $request->name;
        $product->price = $request->price;
        $product->amount = 1;
        $product->currency = $request->currency;
        $product->description = $request->description;
        $product->code = $request->code;
        $product->save_index = 1;
        if ($request->hasfile('image')) {
            $file = $request->file('image');
            $extention = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extention;
            $file->move('assets/image/', $filename);
            $product->image = "$filename";
        }

        $product->save();
        return back();
    }
}
